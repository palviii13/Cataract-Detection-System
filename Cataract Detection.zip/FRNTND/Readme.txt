Thanks for downloading this template!

Template Name: Bethany
Template URL: https://bootstrapmade.com/bethany-free-onepage-bootstrap-theme/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
